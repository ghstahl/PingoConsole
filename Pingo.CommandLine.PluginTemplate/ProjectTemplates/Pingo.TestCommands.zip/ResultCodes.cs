﻿namespace $safeprojectname$
{
    public enum ResultCodes
    {
        Success = 0,
        Fail = 1
    }
}
